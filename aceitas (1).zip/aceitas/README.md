# Aceitas?

A Pen created on CodePen.

Original URL: [https://codepen.io/Leonardo-Pereira-the-bashful/pen/LExZBvZ](https://codepen.io/Leonardo-Pereira-the-bashful/pen/LExZBvZ).

